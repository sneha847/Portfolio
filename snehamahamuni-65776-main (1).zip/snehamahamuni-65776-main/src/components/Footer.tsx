import { Github, Linkedin, Mail, Heart, Code2 } from "lucide-react";

const Footer = () => {
  return (
    <footer className="py-8 px-4 border-t border-border">
      <div className="container max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <span>Built with</span>
            <Heart className="w-4 h-4 text-primary fill-primary" />
            <span>by Sneha Mahamuni</span>
          </div>
          <div className="flex items-center gap-4">
            <a 
              href="https://github.com/sneha847" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 rounded-lg hover:bg-primary/10 transition-colors"
            >
              <Github className="w-5 h-5" />
            </a>
            <a 
              href="https://linkedin.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 rounded-lg hover:bg-primary/10 transition-colors"
            >
              <Linkedin className="w-5 h-5" />
            </a>
            <a 
              href="mailto:mahamunisneha66@gmail.com"
              className="p-2 rounded-lg hover:bg-primary/10 transition-colors"
            >
              <Mail className="w-5 h-5" />
            </a>
            <a 
              href="https://leetcode.com/u/sneha_213/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="p-2 rounded-lg hover:bg-primary/10 transition-colors"
            >
              <Code2 className="w-5 h-5" />
            </a>
          </div>
        </div>
        <div className="text-center text-sm text-muted-foreground mt-4">
          <p>© 2025 Sneha Mahamuni. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
