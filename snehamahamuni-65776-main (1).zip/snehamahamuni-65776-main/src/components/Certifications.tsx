import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Award, Calendar } from "lucide-react";
import certInfosysAI from "@/assets/cert-infosys-ai.jpg";
import certIBMDataScience from "@/assets/cert-ibm-data-science.jpg";
import certDeloitteAnalytics from "@/assets/cert-deloitte-analytics.jpg";
import certSkillIndiaWeb from "@/assets/cert-skill-india-web.jpg";
import certUdemyPythonOOP from "@/assets/cert-udemy-python-oop.jpg";
import certGooglePlayAcademy from "@/assets/cert-google-play-academy.jpg";

const Certifications = () => {
  const certifications = [
    {
      title: "Artificial Intelligence for All",
      issuer: "Infosys Springboard",
      date: "July 2025",
      description: "Successfully completed the Artificial Intelligence for All course, covering fundamental AI concepts and practical applications.",
      skills: ["AI", "Machine Learning", "Infosys", "Springboard"],
      image: certInfosysAI
    },
    {
      title: "Getting Started with Enterprise Data Science",
      issuer: "IBM",
      date: "April 2024",
      description: "In recognition of the commitment to achieve professional excellence in Enterprise Data Science with IBM.",
      skills: ["Python", "Data Science", "Enterprise Applications", "IBM Watson"],
      image: certIBMDataScience
    },
    {
      title: "Data Analytics Job Simulation",
      issuer: "Deloitte",
      date: "June 2025",
      description: "Completed practical tasks in data analysis and forensic technology through Deloitte's job simulation program.",
      skills: ["Data Analysis", "Forensic Technology", "Deloitte", "Forage"],
      image: certDeloitteAnalytics
    },
    {
      title: "Web Design & Development",
      issuer: "Skill India Hub",
      date: "July 2025",
      description: "Successfully participated in the online skilling course on Web Design & Development offered by NSDC through Skill India Digital Hub.",
      skills: ["HTML", "CSS", "Web Development", "Responsive Design"],
      image: certSkillIndiaWeb
    },
    {
      title: "Python OOP: Object Oriented Programming",
      issuer: "Udemy",
      date: "April 2025",
      description: "A complete course in Object Oriented Programming with Python, covering advanced OOP concepts and implementation.",
      skills: ["Python", "OOP", "Design Patterns", "Software Engineering"],
      image: certUdemyPythonOOP
    },
    {
      title: "Google Play Store Listing Certificate",
      issuer: "Google Play Academy",
      date: "July 2025",
      description: "Successfully completed the Google Play Store Listing Certificate requirements, demonstrating expertise in app store optimization and listing best practices.",
      skills: ["Google Play", "App Store Optimization", "Mobile Apps", "Marketing"],
      image: certGooglePlayAcademy
    }
  ];

  return (
    <section id="certifications" className="py-20 px-4 sm:px-6 lg:px-8 bg-card/30">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12 animate-fade-in">
          <h2 className="text-4xl font-bold mb-4 text-gradient">Certifications</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Professional certifications and courses that validate my technical expertise
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {certifications.map((cert, index) => (
            <Card 
              key={index} 
              className="hover:shadow-lg transition-all duration-300 border-primary/20 hover:border-primary/40 card-glow hover:scale-[1.02] overflow-hidden"
            >
              <div className="aspect-video w-full overflow-hidden bg-muted">
                <img 
                  src={cert.image} 
                  alt={`${cert.title} certificate`}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                />
              </div>
              <CardHeader>
                <div className="flex items-start justify-between mb-2">
                  <Award className="w-8 h-8 text-primary" />
                  <Badge variant="secondary" className="flex items-center gap-1">
                    <Calendar className="w-3 h-3" />
                    {cert.date}
                  </Badge>
                </div>
                <CardTitle className="text-xl">{cert.title}</CardTitle>
                <CardDescription className="text-accent font-medium">
                  {cert.issuer}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground mb-4">
                  {cert.description}
                </p>
                <div className="flex flex-wrap gap-2">
                  {cert.skills.map((skill, skillIndex) => (
                    <Badge key={skillIndex} variant="outline" className="border-primary/30">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Certifications;
