import { Card } from "@/components/ui/card";
import { GraduationCap, Award, Target } from "lucide-react";

const About = () => {
  return (
    <section id="about" className="py-20 px-4 bg-gradient-subtle">
      <div className="container max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">
            About <span className="text-gradient">Me</span>
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Results-driven IT professional with comprehensive expertise in software engineering, machine learning, and data analytics. 
            Dedicated to delivering enterprise-grade solutions through innovative problem-solving and cutting-edge technology implementation.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          <Card className="p-6 bg-gradient-card border-border hover:border-primary/50 transition-all card-glow">
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="p-4 rounded-full bg-primary/10">
                <GraduationCap className="w-8 h-8 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Education</h3>
                <p className="text-sm text-muted-foreground mb-1">
                  SMT. Kashibai Navale College Of Engineering
                </p>
                <p className="text-sm text-muted-foreground">
                  BE (Information Technology)
                </p>
                <p className="text-primary font-semibold mt-2">CGPA: 8.50</p>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-card border-border hover:border-primary/50 transition-all card-glow">
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="p-4 rounded-full bg-primary/10">
                <Target className="w-8 h-8 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Focus Areas</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>Full Stack Development</li>
                  <li>Machine Learning</li>
                  <li>Data Analysis</li>
                  <li>Cloud Computing</li>
                </ul>
              </div>
            </div>
          </Card>

          <Card className="p-6 bg-gradient-card border-border hover:border-primary/50 transition-all card-glow">
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="p-4 rounded-full bg-primary/10">
                <Award className="w-8 h-8 text-primary" />
              </div>
              <div>
                <h3 className="text-xl font-bold mb-2">Achievements</h3>
                <ul className="text-sm text-muted-foreground space-y-1">
                  <li>Top Performer in DSA</li>
                  <li>Hackathon Participant</li>
                  <li>Open Source Contributor</li>
                  <li>LeetCode Active</li>
                </ul>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default About;
