import { Card } from "@/components/ui/card";
import { Code2, Database, Brain, Wrench } from "lucide-react";

const Skills = () => {
  const skillCategories = [
    {
      icon: Code2,
      title: "Frontend",
      skills: ["React", "JavaScript", "TypeScript", "CSS", "HTML", "Tailwind CSS"],
    },
    {
      icon: Database,
      title: "Backend",
      skills: ["Python", "MySQL", "MongoDB", "Flask", "Firebase"],
    },
    {
      icon: Brain,
      title: "Data Science",
      skills: ["Machine Learning", "TensorFlow", "Scikit-learn", "Pandas", "Seaborn", "Matplotlib"],
    },
    {
      icon: Wrench,
      title: "Tools",
      skills: ["Git", "Docker", "VS Code", "PyCharm", "Jupyter", "Figma"],
    },
  ];

  const languages = [
    { name: "Python", level: 90 },
    { name: "JavaScript", level: 85 },
    { name: "Java", level: 80 },
    { name: "C++", level: 75 },
    { name: "SQL", level: 85 },
  ];

  return (
    <section id="skills" className="py-20 px-4">
      <div className="container max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">
            Technical <span className="text-gradient">Skills</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            Technologies and tools I work with
          </p>
        </div>

        {/* Skill Categories */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {skillCategories.map((category, index) => {
            const Icon = category.icon;
            return (
              <Card 
                key={index} 
                className="p-6 bg-gradient-card border-border hover:border-primary/50 transition-all card-glow group"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-2 rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold">{category.title}</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill, idx) => (
                    <span 
                      key={idx}
                      className="text-xs px-3 py-1 rounded-full bg-muted text-muted-foreground"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </Card>
            );
          })}
        </div>

        {/* Programming Languages */}
        <Card className="p-8 bg-gradient-card border-border">
          <h3 className="text-2xl font-bold mb-8 text-center">Programming Languages</h3>
          <div className="space-y-6">
            {languages.map((lang, index) => (
              <div key={index}>
                <div className="flex justify-between mb-2">
                  <span className="font-medium">{lang.name}</span>
                  <span className="text-primary">{lang.level}%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-primary rounded-full transition-all duration-1000 ease-out"
                    style={{ width: `${lang.level}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </section>
  );
};

export default Skills;
