import { Card } from "@/components/ui/card";
import { Briefcase, Calendar } from "lucide-react";

const Experience = () => {
  const experiences = [
    {
      role: "Marketing Analyst",
      company: "Aspireway Marketing Private Limited",
      period: "Jan 2025 - Mar 2025",
      description: "Worked on real-world e-commerce dataset to segment customers using RFM model and K-Means clustering. Built an interactive Flask web app to help marketing teams visualize customer clusters and deploy targeted campaigns.",
      achievements: [
        "Applied ML, EDA, and model deployment (Pickle) for data-driven marketing strategies",
        "Developed customer segmentation system supporting direct selling and retention",
        "Created interactive visualizations for marketing campaign optimization",
        "Implemented RFM analysis to identify high-value customer segments"
      ]
    },
    {
      role: "Machine Learning Engineer || Developer",
      company: "MahaSangram Private Limited",
      period: "Oct 2024 - Nov 2024",
      description: "Completed frontend internship developing user-friendly interface pages for AgriSmart app, including essential calculators for farmers. Gained hands-on experience with machine learning in agriculture.",
      achievements: [
        "Built ML crop recommendation system using Random Forest, achieving 95%+ accuracy",
        "Developed frontend interfaces for agricultural calculators and tools",
        "Worked on yield prediction, weed and disease detection systems",
        "Implemented resource management features for smart farming decisions"
      ]
    }
  ];

  return (
    <section id="experience" className="py-20 px-4">
      <div className="container max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4">
            Work <span className="text-gradient">Experience</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            My professional journey
          </p>
        </div>

        <div className="space-y-6">
          {experiences.map((exp, index) => (
            <Card 
              key={index}
              className="p-6 bg-gradient-card border-border hover:border-primary/50 transition-all card-glow"
            >
              <div className="flex flex-col md:flex-row md:items-start md:justify-between mb-4">
                <div className="mb-2 md:mb-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Briefcase className="w-5 h-5 text-primary" />
                    <h3 className="text-xl font-bold">{exp.role}</h3>
                  </div>
                  <p className="text-muted-foreground font-medium">{exp.company}</p>
                </div>
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Calendar className="w-4 h-4" />
                  <span>{exp.period}</span>
                </div>
              </div>
              <p className="text-muted-foreground mb-4">{exp.description}</p>
              <div className="space-y-2">
                {exp.achievements.map((achievement, idx) => (
                  <div key={idx} className="flex items-start gap-2">
                    <span className="text-primary mt-1">▪</span>
                    <span className="text-sm text-muted-foreground">{achievement}</span>
                  </div>
                ))}
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;
