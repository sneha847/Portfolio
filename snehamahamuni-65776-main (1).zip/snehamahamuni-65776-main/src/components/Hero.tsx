import { Button } from "@/components/ui/button";
import { Github, Linkedin, Mail, Download, Code2 } from "lucide-react";

const Hero = () => {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center px-4 py-20">
      <div className="container max-w-6xl mx-auto">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 animate-fade-in">
            <div className="space-y-2">
              <p className="text-primary text-lg font-medium">Hi, I'm</p>
              <h1 className="text-5xl md:text-7xl font-bold">
                Sneha <span className="text-gradient">Mahamuni</span>
              </h1>
              <div className="text-xl md:text-2xl text-muted-foreground space-y-1">
                <p>Web Developer</p>
                <p>Software Engineer</p>
                <p>Data Scientist</p>
              </div>
            </div>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Accomplished IT professional specializing in full-stack development, machine learning, and data-driven solutions. 
              Leveraging advanced technical expertise to architect scalable applications and deliver innovative solutions that drive measurable business impact.
            </p>
            <div className="flex gap-4 flex-wrap">
              <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground glow">
                <a href="#projects">View My Work</a>
              </Button>
              <Button size="lg" variant="outline" className="border-primary/50 hover:bg-primary/10">
                <a href="#contact">Contact Me</a>
              </Button>
              <Button 
                size="lg" 
                variant="outline" 
                className="border-primary/50 hover:bg-primary/10"
                asChild
              >
                <a href="/resume.pdf" download="Sneha_Mahamuni_Resume.pdf">
                  <Download className="w-4 h-4 mr-2" />
                  Resume
                </a>
              </Button>
            </div>
            <div className="flex gap-4 pt-4">
              <a 
                href="https://github.com/sneha847" 
                target="_blank" 
                rel="noopener noreferrer"
                className="p-3 rounded-lg bg-card border border-border hover:border-primary transition-all hover:glow"
              >
                <Github className="w-5 h-5" />
              </a>
              <a 
                href="https://linkedin.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="p-3 rounded-lg bg-card border border-border hover:border-primary transition-all hover:glow"
              >
                <Linkedin className="w-5 h-5" />
              </a>
              <a 
                href="mailto:mahamunisneha66@gmail.com"
                className="p-3 rounded-lg bg-card border border-border hover:border-primary transition-all hover:glow"
              >
                <Mail className="w-5 h-5" />
              </a>
              <a 
                href="https://leetcode.com/u/sneha_213/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="p-3 rounded-lg bg-card border border-border hover:border-primary transition-all hover:glow"
              >
                <Code2 className="w-5 h-5" />
              </a>
            </div>
          </div>
          <div className="relative flex justify-center">
            <div className="relative w-80 h-80 md:w-96 md:h-96">
              <div className="absolute inset-0 bg-gradient-primary rounded-full blur-3xl opacity-20 animate-pulse"></div>
              <img 
                src="https://snehamahamuni.netlify.app/sneha.jpg" 
                alt="Sneha Mahamuni"
                className="relative rounded-2xl w-full h-full object-cover border-2 border-primary/20 card-glow"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
